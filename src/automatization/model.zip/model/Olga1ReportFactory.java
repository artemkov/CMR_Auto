/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package automatization.model;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 *
 * @author Дина
 */
public class Olga1ReportFactory implements ReportFactory
{

    @Override
    public Report makeReport(Content content, Properties properties, List<UniqueList<Map<Content, String>>> sampleList, List<String> sampleNames) 
    {
        
        Report report = new Report();
        report.addProperties(properties);
        report.setContent(content);
        double universe=1000000.0;
        double confLevel=0.95;
        //Главный заголовок
                
        if (report.hasProperty("universe"))
        {
            try
            {
                       Double un = Double.parseDouble(report.getProperty("universe"));
                        universe = un;
                    }
                    catch (NumberFormatException e)
                    {
                        
                    }
                }
                if (report.hasProperty("conflevel"))
                {
                    try
                    {
                        Double un = Double.parseDouble(report.getProperty("conflevel"));
                        confLevel = un;
                    }
                    catch (NumberFormatException e)
                    {
                        
                    }
                }
                
        
        
        
        
        
        return report;
    }
    
}
